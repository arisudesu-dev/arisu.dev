<?
function parse_template($template)
{
global $manlix;

$file=manlix_read_file($manlix[dir][path]."/".$manlix[dir][inc]."/".$manlix[dir][templates]."/".$manlix[template][parse]."/".$template);

	while(list(,$string)=each($file))
	{
	$string=eregi_replace("@bgcolor@",	$manlix[other][bgcolor],			$string);
	$string=eregi_replace("@num@",	$manlix[other][num],			$string);
	$string=eregi_replace("@image@",	$manlix[other][image],			$string);
	$string=eregi_replace("@link@",	$manlix[other][link],			$string);
	$string=eregi_replace("@name@",	$manlix[other][name],			$string);
	$string=eregi_replace("@created@",	$manlix[other][created],			$string);
	$string=eregi_replace("@changed@",	$manlix[other][changed],			$string);
	$string=eregi_replace("@size@",	$manlix[other][size],			$string);	
	$string=eregi_replace("@dirs@",	$manlix[other][dirs],			$string);
	$string=eregi_replace("@files@",	$manlix[other][files],			$string);
	$string=eregi_replace("@images@",	$manlix[other][images],			$string);
	$string=eregi_replace("@back@",	$manlix[other][back],			$string);
	$string=eregi_replace("@path@",	$manlix[other][path],			$string);
	$string=eregi_replace("@time@",	$manlix[other][time],			$string);
	$string=eregi_replace("@error@",	$manlix[other][error],			$string);
	$string=eregi_replace("@sizes@",	$manlix[other][sizes],			$string);
	echo $string;
	flush();
	}
}

function manlix_char_generator($chars,$times)
{
	if(!strlen($chars))		return false;
	elseif(!is_numeric($times))	return false;

	else
	{
		for($i=0;$i<$times;$i++)
		$result.=$chars[rand(0,strlen($chars)-1)];
	}

return $result;
}

function manlix_stripslashes($string)
{
	if(!$string) return false;

	else
	{
	$result=ereg_replace(" +"," ",trim(stripslashes(stripslashes(addslashes($string)))));

		if(!$result){return false;}
		elseif($result!=" "){return $result;}
	}
}

function manlix_read_file($path)
{
	if(!is_file($path))		return false;
	elseif(!filesize($path))	return array();
	elseif($array=file($path))	return $array;

	else

	while(!$array=file($path))	sleep(1);
	return $array;
}

function manlix_time()
{
list($x,$y)=explode(" ",microtime());
return $x+$y;
}

function manlix_normal_numeric($number)
{
	if(!$number)		return false;
	elseif(!is_numeric($number))	return false;

	else

	$strlen_number=strlen($number);

		for($i=$strlen_number-1;$i>-1;$i--)
		{
			$n = $i;				$n++;

			if	(strstr($n / 3,"."))		$new_number .=		$number[$strlen_number - 1 - $i];
			else if	($n != $strlen_number)	$new_number .=	    " ".	$number[$strlen_number - 1 - $i];
			else				$new_number .=		$number[$strlen_number - 1 - $i];
		}

	return $new_number;
}

function back($dir)
{
$array=explode("/",$dir);

	for($i=0;$i<count($array)-2;$i++)
	$result.=$array[$i]."/";

return $result;
}

function read_file($file)
{
$open=fopen ($file,"r");
	while(!feof($open))
	$result.=fgets($open,1024);
fclose($open);
return $result;
}

function search($dir)
{
global $manlix;

	if($OpenDir=opendir($dir))
	{
		while(($file=readdir($OpenDir))!==false)
		{
			if($file!="."&&$file!="..")
			{
				if(is_dir($dir.chr(47).$file))
				{
					if(eregi($manlix[search],$file))
					{
					$image=$manlix[other][images].chr(47);
					$manlix[dirs][]=array(
						name		=>	eregi_replace($manlix[search],"<b>".$manlix[search]."</b>",$file),
						image		=>	$image.="dir.gif",
						link		=>	"?get=".rawurlencode(eregi_replace("^".strtolower($manlix[other][dir])."(/?)","",$dir)).chr(47).rawurlencode($file).chr(47),
						modification	=>	filemtime($dir.chr(47).$file),
						created		=>	filectime($dir.chr(47).$file)
						);
					}
				search($dir.chr(47).$file);
				}

				else
				{
					if(eregi($manlix[search],$file))
					{
					$image=$manlix[other][images].chr(47);
					eregi("\.([a-z0-9_]+)$",$file,$img);

						if(file_exists($manlix[dir][path].chr(47).$manlix[dir][images].chr(47).strtolower($img[1]).".gif"))
						{
						$filesize=filesize($dir.chr(47).$file);
						$manlix[files][]=array(
							name		=>	eregi_replace($manlix[search],"<b>".$manlix[search]."</b>",$file),
							image		=>	$image.=$img[1].".gif",
							link		=>	$manlix[other][url].chr(47).rawurlencode(eregi_replace("^".strtolower($manlix[other][dir])."/","",$dir)).chr(47).rawurlencode($file),
							modification	=>	filemtime($dir.chr(47).$file),
							size		=>	$filesize=($filesize>1024)?manlix_normal_numeric("".round($filesize/1024).""):round(($filesize/1024),3)
							);
						}

						else
						{
						$filesize=filesize($dir.chr(47).$file);
						$manlix[files][]=array(
							name		=>	eregi_replace($manlix[search],"<b>".$manlix[search]."</b>",$file),
							image		=>	$image.="unknown.gif",
							link		=>	$manlix[other][url].chr(47).rawurlencode(eregi_replace("^".strtolower($manlix[other][dir])."/","",$dir)).chr(47).rawurlencode($file),
							modification	=>	filemtime($dir.chr(47).$file),
							size		=>	$filesize=($filesize>1024)?manlix_normal_numeric("".round($filesize/1024).""):round(($filesize/1024),3)
							);
						}
					}
				}
			}
		}
	}
}
?>