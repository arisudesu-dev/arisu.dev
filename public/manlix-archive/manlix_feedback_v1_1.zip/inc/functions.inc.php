<?
function ParseTemplate($TemplateName)
{
global $manlix;

$TemplateFile=manlix_read_file($manlix['dir']['templates'].chr(47).$manlix['template']['parse'].chr(47).$TemplateName);

	while(list($line,$string)=each($TemplateFile))
	{
	$string=ConstantS($string);
	echo $string;
	}
}

function ConstantS($string)
{
return preg_replace_callback("/@([[:alpha:]]+)@/","ConstantR",$string);
}

function ConstantR($array)
{
global $manlix;

	if(!empty($manlix['other'][$array[1]]))
	$string=$manlix['other'][$array[1]];

	else
	$string=null;

return $string;
}

function manlix_stripslashes($string)
{
	if(empty($string))	return false;

	else
	{
	$result=ereg_replace(" +"," ",trim(stripslashes(stripslashes(addslashes($string)))));

		if(!$result)	return false;
		elseif($result!=" ")	return $result;
	}
}

function manlix_read_file($path)
{
	if(!is_file($path))		return false;
	elseif(!filesize($path))	return array();
	elseif($array=file($path))	return $array;

	else
	while(!$array=file($path))	sleep(1);

	return $array;
}
?>