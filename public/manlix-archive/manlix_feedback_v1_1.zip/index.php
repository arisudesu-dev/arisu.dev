<?

#	.................................................................................
#
#		������:	Manlix Feedback, ������: 1.1
#		�����:	Manlix (http://manlix.ru)
#	.................................................................................

$manlix=null;

$manlix=parse_ini_file("./inc/config.inc.dat",1);

include($manlix['file']['functions']);

	while(list($section,$array)=each($manlix))
		while(list($key,$value)=each($array))
		$manlix['other'][chr(73).chr(110).chr(105).ucfirst(strtolower($section)).ucfirst(strtolower($key))]=$value;

if(!empty($_POST))
{
	while(list($key,$value)=each($_POST))
		$manlix['other'][$key]=manlix_stripslashes($value);

	if(empty($_POST['FromName']))
	$manlix['other']['status']=$manlix['other']['error']=$manlix['error']['EmptyName'];

	elseif(empty($_POST['FromMail']))
	$manlix['other']['status']=$manlix['other']['error']=$manlix['error']['EmptyMail'];

	elseif(!eregi("^[a-z0-9]+(([a-z0-9_.-]+)?)@[a-z0-9+](([a-z0-9_.-]+)?)+\.+[a-z]{2,4}$",$manlix['other']['FromMail']))
	$manlix['other']['status']=$manlix['other']['error']=$manlix['error']['InvalidMail'];

	elseif(empty($_POST['FromMessage']))
	$manlix['other']['status']=$manlix['other']['error']=$manlix['error']['EmptyMessage'];

	else
	{
	$manlix['okay']=1;
	$headers=null;
	$headers.="Return-Path: <".$manlix['other']['FromMail'].">".chr(13).chr(10);
	$headers.="From: ".$manlix['other']['FromName']." <".$manlix['other']['FromMail'].">".chr(13).chr(10);
	$headers.="X-Mailer: Manlix Feedback, ������: 1.0".chr(13).chr(10);
	$headers.="Reply-To: ".$manlix['other']['FromName']." <".$manlix['other']['FromMail'].">".chr(13).chr(10);
	$headers.="To: ".$manlix['my']['name']." <".$manlix['my']['mail'].">";
	$headers.="MIME-Version: 1.0".chr(13).chr(10);
	$headers.="Content-Type: ".$manlix['my']['ContentType']."; charset=".$manlix['my']['charset'].chr(13).chr(10);
	$headers.="Content-Transfer-Encoding: 8bit".chr(13).chr(10);
	mail($manlix['my']['mail'],$manlix['my']['subject'],$manlix['other']['FromMessage'],$headers);
	}

	if(isset($manlix['error']))
	{
	reset($_POST);
		while(list($key,$value)=each($_POST))
			$manlix['other'][$key]=htmlspecialchars(manlix_stripslashes($value));
	}
}

ParseTemplate($manlix['templates']['top']);

	if(!isset($manlix['okay']))
	ParseTemplate($manlix['templates']['form']);

	else
	ParseTemplate($manlix['templates']['okay']);

ParseTemplate($manlix['templates']['bottom']);
?>