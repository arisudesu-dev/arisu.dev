<?
function listing($array,$section,$max,$CurrentPage)
{
global $manlix_array_navigation;

$navigation=manlix_array_navigation(
				$array,
				$max,
				$max,
				"?section=".$section."&page=",
				$CurrentPage,
				null,
				null,
				"gray",
				null,
				"#de0000",
				null,
				null,
				chr(32)
				);

return array(
	$manlix_array_navigation['result_strings'],
	$navigation
	);
}

function manlix_array_navigation
(
	$array,			$show_strings,
	$max_show_pages,		$link,
	$page,			$left_symbol,
	$right_symbol,		$color_left_right,
	$color_other_pages,	$color_current_page,
	$color_href_double_active,	$color_href_single_active,
	$separator
)
{
	global	$manlix_array_navigation;

	if (!is_array($array))
	{
	$manlix_array_navigation = "��� ������ � ���� �������� �� ������ ������";
	}

	else if ($array == "")
	{
	$manlix_array_navigation = "�� �� ������� ������ ��� ������ � ��������";
	}

	else
	{

		if (!is_numeric($show_strings))	{$show_strings		= "10";		}
		if (!is_numeric($max_show_pages))	{$max_show_pages	= "10";		}
		if ($link == "")			{$link			= "?page=";	}
		if (!is_numeric($page))		{$page			= "1";		}
		if ($left_symbol == "")		{$left_symbol		= "&lt;";		}
		if ($right_symbol == "")		{$right_symbol		= "&gt;";		}
		if ($separator == "")		{$separator		= " ";		}

	$count	= count($array);

	$all_pages = ceil($count / $show_strings);

	if (!is_numeric($page) or $page < "1" or empty($page))	{$page = "1";		}
	if ($page > $all_pages) 				{$page = "$all_pages";	}

	if (($page + $max_show_pages) <= $all_pages)
	{
	$start = "$page";
	$finish = $page + $max_show_pages;
	}

	if (($page + $max_show_pages) >= $all_pages)
	{
	$start = $all_pages - $max_show_pages;
	$finish = $all_pages;
	}

	if(!isset($pages))		$pages		=null;
	if(!isset($navigation))	$navigation	=null;
	if(!isset($show_string))	$show_string	=null;

	for ($i = $start; $i < $finish + 1; $i++)
	{
		if ($i > "0")
		{
			if ($i > "0"  and $i < "10")	{$link_i = "0$i";	}
			if ($i > "9")		{$link_i = $i;	}

			if ($i == $page)		$pages .= " $separator<font color='$color_current_page'>$link_i</font> $separator ";

			else			$pages .= " $separator<a href='".$link."".$i."'><font color='$color_other_pages'>$link_i</font></a>$separator ";
		}
	}

	if ($page > "2")					{$navigation = "<a href='".$link."1'><font color='$color_href_double_active'>".$left_symbol."".$left_symbol."</font></a> ";	}
	else		 				{$navigation .= "<font color='$color_left_right'>".$left_symbol."".$left_symbol."</font> ";					}

	if (($page - 1) > "0" and ($page - 1) <= $all_pages)	{$navigation .= "<a href='$link".($page - 1)."'><font color='$color_href_single_active'>$left_symbol</font></a> ";		}
	else						{$navigation .= "<font color='$color_left_right'>$left_symbol</font> ";							}

	$navigation .= $pages;

	if ($pages == "")
	{
	$navigation .=  "<font color='$color_current_page'>01</font>";
	$all_pages = "1";
	$page = "1";
	}

	if (($page + 1) <= $all_pages)				{$navigation .= " <a href='$link".($page + 1)."'><font color='$color_href_single_active'>$right_symbol</font></a>";			}
	else						{$navigation .= " <font color='$color_left_right'>$right_symbol</font>";							}

	if ($page < $all_pages - 1)				{$navigation .= " <a href='".$link."".$all_pages."'><font color='$color_href_double_active'>".$right_symbol."".$right_symbol."</font></a>";	}
	else						{$navigation .= " <font color='$color_left_right'>".$right_symbol."".$right_symbol."</font>";					}

	$start = $page * $show_strings - $show_strings;
	$finish = $page * $show_strings;

	if ($page == $all_pages)				{$finish = $count;}

	if ($count <= $show_string)
	{
	$start=0;
	$finish=$count;
	}

	for ($i = $start; $i < $finish; $i++)
	{
	list($string) = explode("\r\n",$array[$i]);
		if ($i < $count)
		{
		$result_strings[] = $string;
		}
	}

	$manlix_array_navigation = array(
					'all_strings'		=> $array,
					'count_all_strings'		=> $count,
					'all_pages'		=> $all_pages,
					'current_page'		=> $page,
					'start_string'		=> $start,
					'finish_string'		=> $finish,
					'result_strings'		=> $result_strings,
					'count_result_strings'	=> count($result_strings),
					'navigation'		=> $navigation
				     );
	return $navigation;
	}
}

function manlix_time()
{
list($x,$y)=explode(" ",microtime());
return $x+$y;
}

function manlix_stripslashes($string)
{
$result=null;

	if(empty($string))
	return false;

	else
	{
	$result=ereg_replace(" +"," ",trim(stripslashes(stripslashes(addslashes($string)))));

		if(empty($result))
		return false;

		else
		return $result;
	}
}

function manlix_even($string)
{
	if(!($string%2))
	return 1;
}

function description($section,$key)
{
	$array=array(
		'dir'	=>	array(
				'Description'		=>	'�����',
				'path'			=>	'���� �� ����� �������',
				'inc'			=>	'��������� ����� �������'
				),

		'file'	=>	array(
				'Description'		=>	'�����',
				'data'			=>	'����',
				'functions'		=>	'�������',
				'password'		=>	'������'
				),
		'other'	=>	array(
				'Description'		=>	'������ (%s - ���������)',
				'js'			=>	'��� ��� ������ ����������, ����� JavaScript',
				'empty'			=>	'�����'
				),


		'script'	=>	array(
				'Description'		=>	'�������������',
				'name'			=>	'��� �������',
				'prefix'			=>	'�������',
				'russian'			=>	'��-������',
				'version'			=>	'������',
				'info'			=>	'����������'
				)
		);

	if(!empty($array[$section]['Description'])&&empty($key))	return ucfirst($array[$section]['Description']);
	if(!empty($array[$section][$key]))			return ucfirst($array[$section][$key]);
	else						return 0;
}

function manlix_read_file($path)
{
	if(!is_file($path))		return false;
	elseif(!filesize($path))	return array();
	elseif($array=file($path))	return $array;

	else
	while(!$array=file($path))sleep(1);

	return $array;
}

function manlix_strip_new_line($string)
{
return preg_replace("/(".chr(9)."|".chr(10)."|".chr(11)."|".chr(12)."|".chr(13).")/",chr(32),$string);
}

function manlix_char_generator($chars,$times)
{

	if(!strlen($chars))		return false;
	elseif(!is_numeric($times))	return false;

	else
	{
	$result=null;
		for($i=0;$i<$times;$i++)
		$result.=$chars[rand(0,strlen($chars)-1)];
	}

return $result;
}
?>