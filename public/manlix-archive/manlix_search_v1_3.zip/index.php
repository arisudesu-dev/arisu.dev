<?

#	.................................................................................
#
#		������:	Manlix Search, ������: 1.3
#		�����:	Manlix (http://manlix.ru)
#	.................................................................................

if(phpversion()<4.3) exit("<font face='verdana' size='1' color='#de0000'><b>������ PHP �������������� ������ ���� 4.3.0 ��� ����, �� ����� �� ���� (���� ������ ��������������: ".phpversion().")</b></font>");

function error($error,$file){exit('<font face=verdana size=1 color=#de0000><b>'.$error.'<br>['.htmlspecialchars($file).']</b></font>');}

@set_time_limit(0);

@SetLocale(LC_ALL,"ru_RU.CP1251");

function CheckConf($conf)
{
	while(list($section,$array)=each($conf))
		while(list($key,$value)=each($array))
			if(!strlen($value))
			error("� ����� ���������� �������, � ������ � ������ <font color=green>".$section."</font>, ���� ���� <font color=green>".$key."</font>",$conf['dir']['path']."/inc/config.inc.dat");
}

$manlix=parse_ini_file("./inc/config.inc.dat",1) or error("�� ���� ��������� �������� ���� ����������","./inc/config.inc.dat");
include($manlix['file']['functions']);

CheckConf($manlix);

	while(list($section,$array)=each($manlix))
		while(list($key,$value)=each($array))
		$manlix['other'][chr(73).chr(110).chr(105).ucfirst(strtolower($section)).ucfirst(strtolower($key))]=$value;

settype($FirstTime=manlix_time(),"integer");

if(isset($_GET['query']))
{
$query=$UserQuery=manlix_stripslashes($_GET['query']);
preg_match_all("/\w+/",$query,$QueryArray);
$TempQuery=array_unique($QueryArray[0]);
$QueryArray[0]=$manlix['result']=null;
	while(list(,$value)=each($TempQuery))
	$QueryArray[0][]=$value;
$result=array();
$found=0;

		if(!$QueryCount=count($QueryArray[0]))
		{
		ParseTemplate($manlix['templates']['top']);
				if(empty($query))
				$manlix['other']['error']=$manlix['error']['EmptyQuery'];
				else
				$manlix['other']['error']=$manlix['error']['EmptyQueryAfterStrip'];
		ParseTemplate($manlix['templates']['error']);
		ParseTemplate($manlix['templates']['bottom']);
		exit;
		}

		elseif($QueryCount==1)
		$query=$QueryArray[0][0];

		else
		{
		$query="(";
			for($i=0;$i<$QueryCount;$i++)
				if($i!=$QueryCount-1)
				$query.=$QueryArray[0][$i]."|";

				else
				$query.=$QueryArray[0][$i];
		$query.=")";
		}

		if(!empty($query))
		{
		ParseTemplate($manlix['templates']['top']);
		$OpenDataFile=fopen($manlix['file']['data'],'r');
		flock($OpenDataFile,1);
		flock($OpenDataFile,2);
			while(!feof($OpenDataFile))
				if(preg_match("/".$query."/i",$string=fgets($OpenDataFile)))
				{
				/*
				list($manlix['other']['link'],$manlix['other']['document'])=split(" ",$string,2);
				$manlix['other']['document']=substr($manlix['other']['document'],0,$manlix['other']['MaxChars']);
				$manlix['other']['document']=trim(preg_replace("/".$query."/i","<b>\\0</b>",$manlix['other']['document']))."...";
				ParseTemplate($manlix['templates']['result']);
				flush();
				*/
				$result[]=$string;
				$found++;
				}
		fclose($OpenDataFile);
			if(!$found)
			{
			$manlix['other']['error']=$manlix['error']['NoFound'];
			ParseTemplate($manlix['templates']['error']);
			}

			else
			{
			$manlix['other']['navigation']=manlix_array_navigation(
							(isset($result))?$result:null,
							(isset($manlix['other']['MaxShow']))?$manlix['other']['MaxShow']:null,
							(isset($manlix['other']['MaxPages']))?$manlix['other']['MaxPages']:null,
							"?query=".$UserQuery."&SearchPage=",
							(isset($_GET['SearchPage']))?$_GET['SearchPage']:null,
							null,
							null,
							(isset($manlix['color']['NotActive']))?$manlix['color']['NotActive']:null,
							null,
							(isset($manlix['color']['CurrentPage']))?$manlix['color']['CurrentPage']:null,
							null,
							null,
							" "
							);

			$manlix['strings']=$manlix_array_navigation;

				while(list($number,$string)=each($manlix['strings']['result_strings']))
				{
				$manlix['other']['num']=$manlix['strings']['count_all_strings']-$manlix['strings']['start_string']-$number;
				list($manlix['other']['link'],$manlix['other']['title'],$manlix['other']['document'])=split(" ",$string,3);
				$manlix['other']['document']=substr($manlix['other']['document'],0,$manlix['other']['MaxChars']);
				$manlix['other']['document']=trim(preg_replace("/".$query."/i","<b>\\0</b>",$manlix['other']['document']))."...";
				ParseTemplate($manlix['templates']['result']);
				flush();
				}
			}
		$manlix['other']['query']=htmlspecialchars($UserQuery);
		$manlix['other']['docs']=(empty($found))?"����":$found;
		$manlix['other']['time']=round(manlix_time()-$FirstTime,3);
		ParseTemplate($manlix['templates']['stat']);
			if(!empty($found))
			ParseTemplate($manlix['templates']['navigation']);
		ParseTemplate($manlix['templates']['bottom']);
		}
}

else
{
$LoadingBody=null;

	$OpenLoadingFile=fopen($manlix['dir']['templates'].chr(47).$manlix['template']['parse'].chr(47).$manlix['templates']['loading'],'r');
	$LoadingBody=fread($OpenLoadingFile,filesize($manlix['dir']['templates'].chr(47).$manlix['template']['parse'].chr(47).$manlix['templates']['loading']));
	fclose($OpenLoadingFile);
$manlix['other']['LoadingHtmlCode']=addslashes(manlix_strip_new_line($LoadingBody));
ParseTemplate($manlix['templates']['form']);
}
?>